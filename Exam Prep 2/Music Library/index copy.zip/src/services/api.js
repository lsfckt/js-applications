import { getUser } from "../utils.js";

const host = 'http://localhost:3030';

const user = getUser();

async function request(method, url, data) {

    const options = {
        method,
        headers: {},
    }

    if (user) {
        options.headers['X-Authorization'] = user.accessToken;
    } else {
        options.headers['Content-Type'] = 'application/json';
    }

    if (data) {
        options.body = JSON.stringify(data);
    }

    try {

        const response = await fetch(host + url, options);

        if (response.status !== 200 && response.status !== 204) {
            throw new Error(`${response.status}: ${response.statusText}`);
        }

        try {
            const data = await response.json();
            return data;

        } catch (error) {
            return error;
        }

    } catch (error) {
        alert(error.message);
        throw error;
    }
}

export const get = request.bind(null, 'GET');
export const post = request.bind(null, 'POST');
export const put = request.bind(null, 'PUT');
export const del = request.bind(null, 'DELETE');